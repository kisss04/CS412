from django.apps import AppConfig


class MiniInstaConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"  # type: ignore[assignment]
    name = "mini_insta"
